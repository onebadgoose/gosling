<div class="form-field">
    <button class="button-secondary" type="button" id="<?php echo $id ?>" name="<?php echo $name ?>">
        <span>Clear CSS Cache for All Pages</span>
    </button>
</div>